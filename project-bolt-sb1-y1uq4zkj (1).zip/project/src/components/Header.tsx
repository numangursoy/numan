import { Instagram } from 'lucide-react';
import { useState, useEffect } from 'react';

const Header = () => {
  const [isScrolled, setIsScrolled] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 50);
    };
    
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const scrollToSection = (id: string) => {
    const element = document.getElementById(id);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <header 
      className={`fixed top-0 left-0 w-full z-50 transition-all duration-300 ${
        isScrolled ? 'bg-white shadow-md py-3' : 'bg-transparent py-5'
      }`}
    >
      <div className="container mx-auto px-4 md:px-6 flex justify-between items-center">
        <h1 className={`text-xl md:text-2xl font-serif transition-all duration-300 ${
          isScrolled ? 'text-primary-800' : 'text-white'
        }`}>
          Zeynep Ceylan
        </h1>
        
        <nav className="hidden md:block">
          <ul className="flex space-x-8">
            {['Hakkımda', 'Çalışma Alanlarım', 'Şema Terapi', 'Seanslar', 'İletişim'].map((item) => (
              <li key={item}>
                <button 
                  onClick={() => scrollToSection(item.toLowerCase().replace(' ', '-'))}
                  className={`text-sm font-medium hover:text-primary-600 transition-colors ${
                    isScrolled ? 'text-gray-700' : 'text-white'
                  }`}
                >
                  {item}
                </button>
              </li>
            ))}
          </ul>
        </nav>
        
        <div className="flex items-center space-x-4">
          <a 
            href="https://wa.me/905326550534" 
            target="_blank" 
            rel="noopener noreferrer"
            className={`text-sm font-medium px-4 py-2 rounded-md transition-all ${
              isScrolled 
              ? 'bg-primary-600 text-white hover:bg-primary-700' 
              : 'bg-white text-primary-600 hover:bg-gray-100'
            }`}
          >
            Randevu Al
          </a>
          
          <a 
            href="https://instagram.com" 
            target="_blank" 
            rel="noopener noreferrer"
            className="text-2xl"
          >
            <Instagram className={`${isScrolled ? 'text-gray-700' : 'text-white'} hover:text-primary-600 transition-colors`} />
          </a>
        </div>
      </div>
      
      <div className="md:hidden absolute right-4 top-4">
        <button 
          onClick={() => document.getElementById('mobile-menu')?.classList.toggle('hidden')}
          className={`p-2 rounded-md ${isScrolled ? 'text-gray-700' : 'text-white'}`}
        >
          <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6h16M4 12h16m-7 6h7" />
          </svg>
        </button>
      </div>
      
      <div id="mobile-menu" className="hidden md:hidden fixed top-0 left-0 w-full h-screen bg-white z-50">
        <div className="p-4 flex justify-end">
          <button 
            onClick={() => document.getElementById('mobile-menu')?.classList.add('hidden')}
            className="p-2 text-gray-700"
          >
            <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
            </svg>
          </button>
        </div>
        
        <ul className="flex flex-col items-center space-y-6 mt-10">
          {['Hakkımda', 'Çalışma Alanlarım', 'Şema Terapi', 'Seanslar', 'İletişim'].map((item) => (
            <li key={item}>
              <button 
                onClick={() => {
                  scrollToSection(item.toLowerCase().replace(' ', '-'));
                  document.getElementById('mobile-menu')?.classList.add('hidden');
                }}
                className="text-lg font-medium text-gray-700 hover:text-primary-600 transition-colors"
              >
                {item}
              </button>
            </li>
          ))}
          
          <li className="mt-8">
            <a 
              href="https://wa.me/905326550534" 
              target="_blank" 
              rel="noopener noreferrer"
              className="text-white bg-primary-600 hover:bg-primary-700 px-6 py-3 rounded-md transition-colors"
            >
              Randevu Al
            </a>
          </li>
        </ul>
      </div>
    </header>
  );
};

export default Header;