const Hero = () => {
  return (
    <section className="relative h-screen bg-hero-pattern bg-cover bg-center bg-no-repeat">
      <div className="absolute inset-0 bg-gradient-radial from-primary-900/50 to-primary-900/80"></div>
      <div className="container relative h-full mx-auto px-4 md:px-6 flex flex-col justify-center items-center text-white z-10">
        <div className="max-w-3xl text-center space-y-6">
          <h1 className="text-5xl md:text-7xl font-serif font-medium mb-4 animate-fadeIn">
            Zeynep Ceylan
          </h1>
          <h2 className="text-2xl md:text-3xl font-light mb-8 animate-fadeIn animation-delay-200">
            Klinik Psikolog
          </h2>
          <p className="text-lg md:text-xl text-gray-100 mb-8 animate-fadeIn animation-delay-300">
            Profesyonel psikoterapi ve şema terapi hizmetleri ile ruhsal sağlığınıza destek oluyorum.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center items-center animate-fadeIn animation-delay-400">
            <a 
              href="#hakkımda" 
              className="px-8 py-3 bg-white text-primary-700 rounded-full hover:bg-gray-100 transition-all duration-300 font-medium"
            >
              Hakkımda
            </a>
            <a 
              href="https://wa.me/905326550534"
              target="_blank"
              rel="noopener noreferrer" 
              className="px-8 py-3 border-2 border-white text-white rounded-full hover:bg-white hover:text-primary-700 transition-all duration-300"
            >
              Randevu Al
            </a>
          </div>
        </div>
      </div>
      
      <div className="absolute bottom-10 left-1/2 transform -translate-x-1/2 animate-bounce">
        <svg className="w-8 h-8 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 14l-7 7m0 0l-7-7m7 7V3" />
        </svg>
      </div>
    </section>
  );
};

export default Hero;