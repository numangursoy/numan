const Services = () => {
  return (
    <section id="çalışma-alanlarım" className="py-20 bg-gradient-to-b from-white to-primary-50">
      <div className="container mx-auto px-4 md:px-6">
        <h2 className="text-3xl md:text-4xl font-serif text-gray-800 mb-16 text-center">Çalışma Alanlarım</h2>
        
        <div className="flex flex-col md:flex-row gap-12">
          <div className="w-full md:w-1/2 space-y-8">
            <div className="bg-white rounded-2xl p-8 shadow-lg hover:shadow-xl transition-all duration-300">
              <h3 className="text-2xl font-serif text-primary-700 mb-4">Bireysel Psikoterapi</h3>
              <p className="text-gray-700 leading-relaxed">
                Modern yaşamın getirdiği stres, kaygı, ilişkisel sorunlar ve duygusal zorlanmalar zamanla yaşam kalitemizi düşürebilir. Bireysel Psikoterapi, kişinin yaşadığı duygusal zorlukları, stres, kaygı, depresyon, ilişki problemleri, travmalar, özgüven eksikliği, uyku ve yeme sorunları gibi alanlarda destek almasını sağlar.
              </p>
            </div>
            
            <div className="bg-white rounded-2xl p-8 shadow-lg hover:shadow-xl transition-all duration-300">
              <h3 className="text-2xl font-serif text-primary-700 mb-4">Terapi Yaklaşımlarım</h3>
              <p className="text-gray-700 leading-relaxed">
                Terapi sürecinde, şema terapi ve bilişsel davranışçı terapi (BDT) yaklaşımlarını esas alıyorum. Bu yöntemler; kişinin düşünce kalıplarını, duygusal tepkilerini ve yaşamında tekrar eden örüntüleri fark etmesini ve dönüştürmesini amaçlar.
              </p>
            </div>
          </div>
          
          <div className="w-full md:w-1/2">
            <div className="h-full flex items-center justify-center bg-gradient-to-br from-primary-100 to-secondary-100 rounded-2xl p-10 shadow-lg">
              <div className="grid grid-cols-2 gap-4">
                <div className="bg-white p-6 rounded-xl shadow-md hover:shadow-lg transition-all duration-300">
                  <h4 className="text-lg font-medium text-primary-700 mb-2">Kaygı ve Stres</h4>
                  <p className="text-sm text-gray-600">Günlük yaşamın zorluklarıyla başa çıkma</p>
                </div>
                <div className="bg-white p-6 rounded-xl shadow-md hover:shadow-lg transition-all duration-300">
                  <h4 className="text-lg font-medium text-primary-700 mb-2">Depresyon</h4>
                  <p className="text-sm text-gray-600">Duygusal destek ve iyileşme süreci</p>
                </div>
                <div className="bg-white p-6 rounded-xl shadow-md hover:shadow-lg transition-all duration-300">
                  <h4 className="text-lg font-medium text-primary-700 mb-2">İlişki Sorunları</h4>
                  <p className="text-sm text-gray-600">Sağlıklı ilişkiler geliştirme</p>
                </div>
                <div className="bg-white p-6 rounded-xl shadow-md hover:shadow-lg transition-all duration-300">
                  <h4 className="text-lg font-medium text-primary-700 mb-2">Travma</h4>
                  <p className="text-sm text-gray-600">Travma sonrası iyileşme desteği</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Services;